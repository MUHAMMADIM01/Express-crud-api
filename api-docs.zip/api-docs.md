# REST API Documentation - Express.js CRUD API

## Overview

This is a simple CRUD API built with Express.js. It allows users to Create, Read, Update, and Delete items from a MongoDB database. The API is suitable for educational purposes and demonstrates RESTful design practices.

## Base URL

```
https://your-api-name.onrender.com/api/items
```

_Replace with your actual deployed Render URL._

---

## Endpoints

### 1. Create an Item

- **URL:** `/api/items`
- **Method:** `POST`
- **Description:** Adds a new item to the database.

#### Request Body

```json
{
  "name": "Paracetamol",
  "price": 500
}
```

#### Response

```json
{
  "message": "Item created successfully",
  "data": {
    "_id": "64abc123def456",
    "name": "Paracetamol",
    "price": 500,
    "createdAt": "2025-07-11T12:00:00Z"
  }
}
```

---

### 2. Get All Items

- **URL:** `/api/items`
- **Method:** `GET`
- **Description:** Returns a list of all items in the database.

#### Response

```json
[
  {
    "_id": "64abc123def456",
    "name": "Paracetamol",
    "price": 500
  },
  {
    "_id": "64abc987xyz321",
    "name": "Amoxicillin",
    "price": 700
  }
]
```

---

### 3. Get Single Item

- **URL:** `/api/items/:id`
- **Method:** `GET`
- **Description:** Returns a single item by ID.

#### Response

```json
{
  "_id": "64abc123def456",
  "name": "Paracetamol",
  "price": 500
}
```

---

### 4. Update Item

- **URL:** `/api/items/:id`
- **Method:** `PUT`
- **Description:** Updates an existing item by ID.

#### Request Body

```json
{
  "name": "Paracetamol Extra",
  "price": 600
}
```

#### Response

```json
{
  "message": "Item updated successfully",
  "data": {
    "_id": "64abc123def456",
    "name": "Paracetamol Extra",
    "price": 600
  }
}
```

---

### 5. Delete Item

- **URL:** `/api/items/:id`
- **Method:** `DELETE`
- **Description:** Deletes an item from the database by ID.

#### Response

```json
{
  "message": "Item deleted successfully"
}
```

---

## Error Handling

- If an item is not found, the API returns:

```json
{
  "error": "Item not found"
}
```

- If the request is malformed:

```json
{
  "error": "Invalid data format"
}
```

---

## Status Codes

- `200 OK` – Request successful
- `201 Created` – New resource created
- `400 Bad Request` – Validation or syntax error
- `404 Not Found` – Resource not found
- `500 Internal Server Error` – Server-side issue

---

## Authentication

_No authentication is currently required. This API is open for learning purposes only._

---

## Contact

For any inquiries or suggestions, feel free to reach out:

- Developer: [Your Name]
- GitHub: https://github.com/MIMUHAMMADU
